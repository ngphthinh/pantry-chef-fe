import { configureStore } from "@reduxjs/toolkit";
import authReducer from "@/features/auth/authSlice";
import userReducer from "@/features/auth/userSlice";
import themeReducer from "@/core/theme/themeSlice";
import aiReducer from "@/features/ai/aiSlice";
import pantryReducer from "@/features/pantry/pantrySlice";
import mealPlanReducer from "@/features/mealplan/mealPlanSlice";
import customRecipeReducer from "@/features/customRecipe/customRecipeSlice";
import recipeReducer from "@/features/recipe/recipeSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    theme: themeReducer,
    user: userReducer,
    ai: aiReducer,
    pantry: pantryReducer,
    mealPlan: mealPlanReducer,
    recipe: recipeReducer,
    customRecipe: customRecipeReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
